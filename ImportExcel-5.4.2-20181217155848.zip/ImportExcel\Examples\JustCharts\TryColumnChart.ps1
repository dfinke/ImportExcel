try {. $PSScriptRoot\..\..\LoadPSD1.ps1} catch {}

ColumnChart (.\TargetData.ps1) "A ColumnChart"
