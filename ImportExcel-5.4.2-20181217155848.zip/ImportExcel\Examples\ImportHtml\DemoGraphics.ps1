try {. $PSScriptRoot\..\..\LoadPSD1.ps1} catch {}


Import-Html "http://en.wikipedia.org/wiki/Demographics_of_India" 4