try {. $PSScriptRoot\..\..\LoadPSD1.ps1} catch {}

Import-Html "http://www.science.co.il/PTelements.asp" 1