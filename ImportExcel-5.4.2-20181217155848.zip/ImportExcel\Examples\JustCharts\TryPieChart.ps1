try {. $PSScriptRoot\..\..\LoadPSD1.ps1} catch {}

PieChart (.\TargetData.ps1) "A PieChart"