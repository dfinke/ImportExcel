$p = @{
    Name = "ImportExcel"
    NuGetApiKey = $NuGetApiKey
    ReleaseNote = "Add NumberFormat parameter"
}

Publish-Module @p