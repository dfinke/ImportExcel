try {. $PSScriptRoot\..\..\LoadPSD1.ps1} catch {}

Import-Html "https://en.wikipedia.org/wiki/List_of_Star_Trek:_The_Original_Series_episodes" 2