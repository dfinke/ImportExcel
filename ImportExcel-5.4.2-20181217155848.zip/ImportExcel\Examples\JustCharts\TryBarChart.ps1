try {. $PSScriptRoot\..\..\LoadPSD1.ps1} catch {}

BarChart (.\TargetData.ps1) "A BarChart"